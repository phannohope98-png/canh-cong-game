# Hoạt ảnh kỹ năng 88

24 kỹ năng, mỗi kỹ năng 8 khung ảnh khác nhau: tổng cộng 192 PNG nền trong suốt. Bốn atlas WebP dùng trực tiếp trong game; animations.json mô tả hàng, khung, tốc độ và điểm neo. skill-fx88.js phát hoạt ảnh theo thời gian của đòn đánh.

Hiệu ứng thường dài khoảng 0,6 giây, có phát động, va chạm và tan biến. Phép duy trì giữ các khung giữa rồi tan khi hết thời gian. Mìn chỉ chớp ngòi khi chờ, nổ khi kích hoạt. Dây móc đi tới mục tiêu thực. Kích thước hình hiệu ứng tối đa 48 đơn vị trong map, không phóng theo bán kính sát thương. Mìn 22, phép hỗ trợ 44. Vòng hỗ trợ bổ sung có bán kính tối đa 25.

Các ảnh source-0…3.png và hook-source.png được tạo bằng công cụ imagegen tích hợp. Khung được đăng ký lại vào atlas để không lấy nhầm mảnh của hàng bên cạnh; ảnh gốc được giữ trong bộ này.

Prompt set: 2D hand-painted fantasy tower-defense VFX animation atlas; transparent background; eight distinct sequential frames per effect; anticipation, ignition, release, impact, breakup, dispersal, fading particles; compact forms, fixed ground pivot, crisp small mobile scale; no UI, no characters, no giant weapon icons, no text or rendered checkerboard.

- Bộ 1: cổng triệu hồi xanh; va chạm khiên; mưa tên xanh; gió né tránh; sét tím; lồng tinh thể tím.
- Bộ 2: nổ pháo; mìn đồng; chém rìu đỏ; sóng chiến hống; búa đập đất; cổng triệu hồi vàng.
- Bộ 3: đâm giáo xanh; rễ trói; tinh thể vỡ; ảo ảnh; chấn động đất; hào quang phòng thủ.
- Bộ 4: chém xoay đỏ; dây móc thép; gió nhạc hỗ trợ; lá hồi phục; vòm bảo hộ; tia tăng lực xanh vàng.
- Bộ dây móc bổ sung: eight isolated compact iron-hook throw/catch/retraction frames, short chain, empty margins, no chain extending into another cell.

PNG riêng nằm trong frames/. Atlas 128×128 mỗi khung, điểm neo (64,106). Các hiệu ứng là hình chuyển động trong trận, biểu tượng ở nút kỹ năng vẫn giữ riêng.
