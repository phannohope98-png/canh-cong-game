# Sửa đạn kỹ năng và kíp trụ 89

- Đạn kỹ năng người lùn là viên pháo tròn, không còn hình thoi. Búa và tinh thể có bộ khung riêng. Mỗi loại 8 khung xoay, khói/tia sáng thay đổi; bay từ tướng đến điểm va chạm theo đường cong.
- Chiều cao hiển thị Elf và phù thủy trên trụ: 29 đơn vị map; người lùn: 25. Tướng thường: 32. Các nhân vật được bù lại phần thu nhỏ nền trụ để không bị teo theo từng map, vẫn neo chân vào sàn trụ. Trụ pháo có người lùn điều khiển hiện rõ hơn.
- skill-projectiles89.webp là atlas 8 cột × 3 hàng. PNG riêng và animated WebP kèm theo. Code sửa nằm trong mobile83.js, battle57.js, skill-fx88.js.

Ảnh tạo bằng imagegen tích hợp. Prompt: “2D handpainted fantasy tower-defense projectile animation sheet; eight columns, three rows; transparent background; isolated compact sprites with empty margins; row one rotating round iron cannonball with brass trim and smoky ember tail, row two tumbling golden steel hammer, row three refracting violet crystal; eight distinct phases each; stable centers; no environment, UI, labels or placeholder diamonds.”

Kiểm tra: 144 tổ hợp cấp trụ/thế giới có kíp trụ và tỷ lệ nhất quán; ba projectile đều có 8 khung khác nhau. Xem lại trực tiếp trận Elf ở khung 844×390.
